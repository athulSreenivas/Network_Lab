#! /bin/bash

echo "Enter a number to reverse :"

read number 

echo $number | rev
