#! /bin/bash

echo `date`

echo $PWD
